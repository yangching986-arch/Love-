APK build korar 2 ta way:

1) Android Studio: folder ta Open koro -> Build > Build APK(s)
   APK: app/build/outputs/apk/debug/app-debug.apk

2) GitHub (computer lagbe na): notun repo te ei sob file upload koro (.github folder soho)
   -> Actions tab -> "Build APK" -> run hole Artifacts theke OurLove-apk download koro.
